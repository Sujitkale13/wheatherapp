import React, { useCallback, useEffect, useState } from "react";

const GEO = "https://geocoding-api.open-meteo.com/v1/search";
const FORECAST = "https://api.open-meteo.com/v1/forecast";
const AIR = "https://air-quality-api.open-meteo.com/v1/air-quality";

function condition(code) {
  if (code === 0) return ["Clear sky", "☀️"];
  if ([1, 2].includes(code)) return ["Partly cloudy", "🌤️"];
  if (code === 3) return ["Overcast", "☁️"];
  if ([45, 48].includes(code)) return ["Foggy", "🌫️"];
  if ([51, 53, 55, 56, 57].includes(code)) return ["Drizzle", "🌦️"];
  if ([61, 63, 65, 66, 67, 80, 81, 82].includes(code)) return ["Rain", "🌧️"];
  if ([71, 73, 75, 77, 85, 86].includes(code)) return ["Snow", "🌨️"];
  if ([95, 96, 99].includes(code)) return ["Thunderstorm", "⛈️"];
  return ["Variable conditions", "🌤️"];
}
function aqiLabel(aqi) {
  if (aqi == null) return ["Unavailable", "unknown"];
  if (aqi <= 50) return ["Good", "good"];
  if (aqi <= 100) return ["Moderate", "moderate"];
  if (aqi <= 150) return ["Unhealthy for sensitive groups", "sensitive"];
  if (aqi <= 200) return ["Unhealthy", "unhealthy"];
  if (aqi <= 300) return ["Very unhealthy", "very-unhealthy"];
  return ["Hazardous", "hazardous"];
}
function dayLabel(date, i) {
  return i === 0 ? "Today" : new Date(`${date}T12:00:00`).toLocaleDateString("en-US", { weekday: "short" });
}
function formatLocalTime(dateTime) {
  if (!dateTime || !dateTime.includes("T")) return "—";
  const [hours, minutes] = dateTime.split("T")[1].slice(0, 5).split(":").map(Number);
  const suffix = hours >= 12 ? "PM" : "AM";
  return `${hours % 12 || 12}:${String(minutes).padStart(2, "0")} ${suffix}`;
}
function hourLabel(dateTime) {
  return formatLocalTime(dateTime);
}
async function getJson(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error("The weather service could not complete the request.");
  return res.json();
}

export default function App() {
  const [query, setQuery] = useState("Pune");
  const [place, setPlace] = useState({
    name: "Pune", admin1: "Maharashtra", country: "India",
    latitude: 18.5204, longitude: 73.8567, timezone: "Asia/Kolkata"
  });
  const [weather, setWeather] = useState(null);
  const [air, setAir] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [updated, setUpdated] = useState(null);

  const loadPlace = useCallback(async (target) => {
    setLoading(true);
    setError("");
    try {
      const params = new URLSearchParams({
        latitude: String(target.latitude),
        longitude: String(target.longitude),
        timezone: "auto",
        forecast_days: "7",
        current: "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m,pressure_msl",
        hourly: "temperature_2m,precipitation_probability,weather_code,relative_humidity_2m,uv_index,wind_speed_10m",
        daily: "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset,uv_index_max",
      });
      const airParams = new URLSearchParams({
        latitude: String(target.latitude),
        longitude: String(target.longitude),
        timezone: "auto",
        current: "us_aqi,pm2_5,pm10,ozone,nitrogen_dioxide",
        hourly: "us_aqi,pm2_5,pm10",
        forecast_days: "1",
      });
      const [w, a] = await Promise.all([
        getJson(`${FORECAST}?${params}`),
        getJson(`${AIR}?${airParams}`).catch(() => null)
      ]);
      setPlace(target);
      setQuery(target.name);
      setWeather(w);
      setAir(a);
      setUpdated(new Date());
    } catch (e) {
      setError(e.message || "Unable to load weather. Check your internet connection.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadPlace(place); }, []); // Initial Pune forecast.

  async function searchCity(e) {
    e.preventDefault();
    const name = query.trim();
    if (!name) { setError("Enter a city name first."); return; }
    setLoading(true);
    setError("");
    try {
      const data = await getJson(`${GEO}?${new URLSearchParams({ name, count: "1", language: "en", format: "json" })}`);
      const p = data.results?.[0];
      if (!p) throw new Error(`No city found for "${name}". Try another spelling.`);
      await loadPlace({
        name: p.name, admin1: p.admin1 || "", country: p.country || "",
        latitude: p.latitude, longitude: p.longitude, timezone: p.timezone || "auto"
      });
    } catch (e) {
      setLoading(false);
      setError(e.message || "City search failed.");
    }
  }

  const current = weather?.current;
  const daily = weather?.daily;
  const hourly = weather?.hourly;
  const [conditionText, conditionIcon] = current ? condition(current.weather_code) : ["Loading weather", "🌤️"];
  const airCurrent = air?.current;
  const [airText, airClass] = aqiLabel(airCurrent?.us_aqi);
  const now = weather?.current?.time;
  const nextHours = hourly && now ? hourly.time.map((t, i) => ({ t, i })).filter(x => x.t >= now).slice(0, 12) : [];
  const locationLine = [place.admin1, place.country].filter(Boolean).join(", ");

  return (
    <main className="app">
      <header className="nav">
        <a className="logo" href="#"><span className="logo-icon">☀</span> skycast<span className="blue-dot">.</span></a>
        <span className="live"><i /> LIVE WEATHER</span>
      </header>

      <form className="search" onSubmit={searchCity}>
        <span className="pin">⌖</span>
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search a city..." aria-label="City name" />
        <button disabled={loading}>{loading ? "Loading…" : "⌕ Search"}</button>
      </form>
      {error && <div className="error" role="alert">{error}</div>}

      <section className="hero">
        <div className="hero-text">
          <p className="kicker">CURRENT WEATHER</p>
          <h1>{place.name}</h1>
          <p className="location">{locationLine}</p>
          {loading && !current ? <p className="loading">Getting live weather…</p> : <>
            <div className="temp">{current ? Math.round(current.temperature_2m) : "—"}<span>°C</span></div>
            <div className="condition">{conditionIcon} {conditionText}</div>
            <p className="feels">Feels like {current ? Math.round(current.apparent_temperature) : "—"}°C</p>
          </>}
        </div>
        <div className="hero-art" aria-hidden="true"><div className="sun-ball" />{conditionIcon}</div>
        <div className="hero-bottom">
          <span>🌅 Sunrise <b>{daily?.sunrise?.[0] ? formatLocalTime(daily.sunrise[0]) : "—"}</b></span>
          <span>🌇 Sunset <b>{daily?.sunset?.[0] ? formatLocalTime(daily.sunset[0]) : "—"}</b></span>
          <span>☀️ UV index <b>{daily?.uv_index_max?.[0] ?? "—"}</b></span>
        </div>
      </section>

      <section className="section">
        <div className="section-title"><div><p className="kicker">RIGHT NOW</p><h2>Weather details</h2></div><span className="pill">Live conditions</span></div>
        <div className="metric-grid">
          <Metric icon="💧" label="Humidity" value={current ? `${current.relative_humidity_2m}%` : "—"} />
          <Metric icon="💨" label="Wind speed" value={current ? `${Math.round(current.wind_speed_10m)} km/h` : "—"} />
          <Metric icon="🌡️" label="Pressure" value={current ? `${Math.round(current.pressure_msl)} hPa` : "—"} />
          <Metric icon="🌧️" label="Precipitation" value={current ? `${current.precipitation} mm` : "—"} />
        </div>
      </section>

      <section className="section">
        <div className="section-title"><div><p className="kicker">BREATHE BETTER</p><h2>Air quality</h2></div><span className="pill">US AQI scale</span></div>
        <div className={`aqi-card ${airClass}`}>
          <div className="aqi-main">
            <div><p className="muted">Air Quality Index</p><div className="aqi-number">{airCurrent?.us_aqi ?? "—"} <span>AQI</span></div><strong>{airText}</strong></div>
            <div className="aqi-gauge"><div className="gauge-track"><div className="gauge-needle" style={{left: `${Math.min(100, Math.max(0, (airCurrent?.us_aqi ?? 0) / 300 * 100))}%`}} /></div><div className="gauge-labels"><span>Good</span><span>Moderate</span><span>Poor</span></div></div>
          </div>
          <div className="pollutants">
            <Pollutant label="PM2.5" value={airCurrent?.pm2_5} unit="µg/m³" />
            <Pollutant label="PM10" value={airCurrent?.pm10} unit="µg/m³" />
            <Pollutant label="Ozone" value={airCurrent?.ozone} unit="µg/m³" />
            <Pollutant label="Nitrogen dioxide" value={airCurrent?.nitrogen_dioxide} unit="µg/m³" />
          </div>
          <p className="aqi-note">Air quality is estimated for this location. If you have breathing sensitivity, check local official advisories before outdoor activity.</p>
        </div>
      </section>

      <section className="section">
        <div className="section-title"><div><p className="kicker">HOUR BY HOUR</p><h2>Today's forecast</h2></div><span className="pill">Next 12 hours</span></div>
        <div className="hourly-scroll">
          {nextHours.map(({t, i}) => {
            const [, icon] = condition(hourly.weather_code[i]);
            return <article className="hour" key={t}><span className="hour-time">{hourLabel(t)}</span><span className="hour-icon">{icon}</span><strong>{Math.round(hourly.temperature_2m[i])}°</strong><span className="hour-rain">💧 {hourly.precipitation_probability[i] ?? 0}%</span></article>;
          })}
          {!hourly && <p className="muted">Hourly forecast is loading…</p>}
        </div>
      </section>

      <section className="section">
        <div className="section-title"><div><p className="kicker">THE WEEK AHEAD</p><h2>7-day forecast</h2></div><span className="pill">Daily outlook</span></div>
        <div className="week-list">
          {daily?.time?.map((date, i) => {
            const [label, icon] = condition(daily.weather_code[i]);
            const max = Math.max(...daily.temperature_2m_max);
            const min = Math.min(...daily.temperature_2m_min);
            const left = ((daily.temperature_2m_min[i] - min) / Math.max(1, max - min)) * 100;
            const width = ((daily.temperature_2m_max[i] - daily.temperature_2m_min[i]) / Math.max(1, max - min)) * 100;
            return <article className="week-row" key={date}>
              <span className="week-day">{dayLabel(date, i)}</span><span className="week-icon">{icon}</span><span className="week-condition">{label}</span>
              <span className="week-rain">💧 {daily.precipitation_probability_max?.[i] ?? 0}%</span>
              <strong>{Math.round(daily.temperature_2m_min[i])}°</strong><div className="temp-track"><div style={{left: `${left}%`, width: `${Math.max(8,width)}%`}} /></div><strong>{Math.round(daily.temperature_2m_max[i])}°</strong>
            </article>;
          })}
        </div>
      </section>

      <section className="section">
        <div className="section-title"><div><p className="kicker">EXPLORE THE AREA</p><h2>Map of {place.name}</h2></div><a className="map-link" href={`https://www.google.com/maps/search/?api=1&query=${place.latitude},${place.longitude}`} target="_blank" rel="noreferrer">Open Google Maps ↗</a></div>
        <div className="map-frame">
          <iframe title={`Map of ${place.name}`} loading="lazy" referrerPolicy="no-referrer-when-downgrade" src={`https://maps.google.com/maps?q=${place.latitude},${place.longitude}&z=11&output=embed`} />
        </div>
        <p className="map-caption">Map centered on {place.name}. Use “Open Google Maps” for directions, places and traffic in Google Maps.</p>
      </section>

      <footer className="footer">
        <span>{updated ? `Updated ${updated.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}` : "Weather updates"}</span>
        <button onClick={() => loadPlace(place)} disabled={loading}>↻ Refresh data</button>
        <span>Weather & air data by <a href="https://open-meteo.com/" target="_blank" rel="noreferrer">Open-Meteo</a></span>
      </footer>
    </main>
  );
}

function Metric({icon,label,value}) {
  return <article className="metric"><span className="metric-icon">{icon}</span><span className="metric-label">{label}</span><strong>{value}</strong></article>;
}
function Pollutant({label,value,unit}) {
  return <div className="pollutant"><span>{label}</span><strong>{value == null ? "—" : Number(value).toFixed(1)}</strong><small>{unit}</small></div>;
}